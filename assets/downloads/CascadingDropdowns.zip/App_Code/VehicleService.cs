﻿using System.Collections.Generic;
using System.Linq;

public class VehicleService : IVehicleService
{
    #region IVehicleService Members

    public Dictionary<string, string> GetMakes()
    {
        Dictionary<string, string> makes = new Dictionary<string, string>();
        
        using (VehiclesDataContext vdc = new VehiclesDataContext())
        {
            makes = vdc.GetMakes().ToDictionary(m => m.MakeId.ToString(), m => m.MakeName);
        }

        return makes;
    }

    public Dictionary<string, string> GetModels(string make)
    {
        Dictionary<string, string> models = new Dictionary<string, string>(); 
        int makeId;
        int.TryParse(make, out makeId);

        using (VehiclesDataContext vdc = new VehiclesDataContext())
        {
            models = vdc.GetModels(makeId).ToDictionary(m => m.ModelId.ToString(), m => m.ModelName);
        }

        return models;
    }

    public Dictionary<string, string> GetDerivatives(string make, string model)
    {
        Dictionary<string, string> derivatives = new Dictionary<string, string>();
        int makeId, modelId;
        int.TryParse(make, out makeId);
        int.TryParse(model, out modelId);

        using (VehiclesDataContext vdc = new VehiclesDataContext())
        {
            derivatives = vdc.GetDerivatives(makeId, modelId).ToDictionary(d => d.DerivativeId.ToString(), d => d.DerivativeName);
        }

        return derivatives;
    }

    #endregion
}
