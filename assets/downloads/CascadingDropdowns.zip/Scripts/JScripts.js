﻿// Check to see if namespace already exists and create
var SteveTaylor = window.SteveTaylor || {};

// Some helper methods
SteveTaylor.Common = function(){
    return{
        // Handle errors here
        handleError: function(msg){
            alert(msg);   
        },
        // Main call service helper
        callService: function(url, method, callback)
        {
            $.ajax({
                url: url,
                type: method,
                contentType: "application/json",
                dataType: "json", 
                success: callback,
                error: function(xhr, message, ex) 
                    { SteveTaylor.Common.handleError("Ajax error:" + message); }
            });
        }
    }
}();

// This object populates our dropdowns
SteveTaylor.VehicleSearch = function(){    
    return{
        getMakes: function(){
             $("#Makes").removeOption(/./).addOption("-1", "Loading...");
            
             SteveTaylor.Common.callService("VehicleService.svc/GetMakes", "GET", function(result){
                 
                 for(var i=0; i < result.length; i++)
                    $("#Makes").addOption(result[i].Key, result[i].Value);
            
                 $("#Makes").addOption("-1", "Any Make").trigger("change"); 
             });
        },
        getModels: function(){
            $("#Models").removeOption(/./).addOption("-1", "Loading...");
            
            SteveTaylor.Common.callService("VehicleService.svc/GetModels/" + $("#Makes").val(), "GET",                function(result){
                    for(var i=0; i < result.length; i++)
                        $("#Models").addOption(result[i].Key, result[i].Value);
                
                    $("#Models").addOption("-1", "Any Model").trigger("change"); 
                });
        },   
        getDerivatives: function(){
            $("#Derivatives").removeOption(/./).addOption("-1", "Loading...");
            
            SteveTaylor.Common.callService("VehicleService.svc/GetDerivatives/" + $("#Makes").val() + "/" + $("#Models").val(), "GET",
                function(result){
                    for(var i=0; i < result.length; i++)
                        $("#Derivatives").addOption(result[i].Key, result[i].Value);
                
                     $("#Derivatives").addOption("-1", "Any Derivative").trigger("change"); 
                });
        },    
        init: function(resultsPage){
            // Bind events
            $("#Makes").bind("change", SteveTaylor.VehicleSearch.getModels);
            $("#Models").bind("change", SteveTaylor.VehicleSearch.getDerivatives);
            
            // Initialise makes dropdown
            SteveTaylor.VehicleSearch.getMakes();
        }
    }
}();

$(document).ready(SteveTaylor.VehicleSearch.init);
